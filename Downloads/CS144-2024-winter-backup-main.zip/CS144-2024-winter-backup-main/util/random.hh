#pragma once

#include <random>

std::default_random_engine get_random_engine();
